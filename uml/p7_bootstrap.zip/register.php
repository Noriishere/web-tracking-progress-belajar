<?php
session_start();
require 'db.php';
include 'header.php';

$errors = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama  = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $jk    = $_POST['jk'] ?? '';
    $hobi  = $_POST['hobi'] ?? [];
    $hobi_str = implode(", ", $hobi);
    $pass = $_POST['password'];


    if ($nama == "" || $email == "" || $pass == "" || $jk == "") {
        $errors = "Semua field wajib diisi";
    } elseif (empty($hobi)) {
        $errors = "Pilih minimal satu hobi";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors = "Format email tidak valid";
    } else {
        $cek = mysqli_query($koneksi, "SELECT id FROM users WHERE email='$email'");
        if (mysqli_num_rows($cek) > 0) {
            $errors = "Email sudah terdaftar";
        } else {
            $fotoName = null;
            if (!empty($_FILES['foto']['name'])) {
                $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
                $fotoName = time() . '_' . rand(1000,9999) . '.' . $ext;
                $target = "uploads/" . $fotoName;

                if (!move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
                    $errors = "Gagal upload foto";
                }
            }

            if ($errors == "") {
                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $sql  = "INSERT INTO users (nama, email, jk, hobi, password, foto)
                        VALUES ('$nama', '$email', '$jk', '$hobi_str', '$hash', '$fotoName')";
                if (mysqli_query($koneksi, $sql)) {
                    $_SESSION['success'] = "Registrasi berhasil, silakan login";
                    header("Location: login.php");
                    exit;
                } else {
                    $errors = "Gagal simpan ke database";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
</head>
<body class="bg-danger d-flex justify-content-center align-items-center ">
    <div class="card shadow rounded-4 p-3" style="witdh:20%;">
        <div class="card-body">

        <h4>Registrasi Akun</h4>

        <div class="mt-2 mb-2 d-flex justify-content-center gap-3" >
                <a href="https://www.google.com" class="text-dark" ><i class="bi bi-google"></i></a>
                <a href="https://www.instagram.com" class="text-dark"><i class="bi bi-instagram"></i></a>
                <a href="https://www.facebook.com" class="text-dark"><i class="bi bi-facebook"></i></a>
                <a href="https://www.twitter.com" class="text-dark"><i class="bi bi-twitter-x"></i></a>
                <a href="https://www.github.com" class="text-dark"><i class="bi bi-github"></i></a>
            </div>

        <?php if ($errors != ""): ?>
            <p style="color:red;"><?php echo $errors; ?></p>
        <?php endif; ?>

        <form action="" method="post" enctype="multipart/form-data">
            <label class="form-label fw-semibold">Nama</label><br>
            <input class="form-control" type="text" name="nama" value="<?php echo isset($nama) ? $nama : ''; ?>"><br>

            <label class="form-label fw-semibold">Email</label><br>
            <input class="form-control" type="email" name="email" value="<?php echo isset($email) ? $email : ''; ?>"><br>

            <label class="form-label fw-semibold">Jenis Kelamin</label><br>
            <label><input type="radio" name="jk" value="Laki-laki"> Laki-laki</label><br>
            <label><input type="radio" name="jk" value="Perempuan"> Perempuan</label><br>

            <label class="form-label fw-semibold">Hobi</label><br>
            <label><input type="checkbox" name="hobi[]" value="Membaca"> Membaca</label><br>
            <label><input type="checkbox" name="hobi[]" value="Olahraga"> Olahraga</label><br>
            <label><input type="checkbox" name="hobi[]" value="Memasak"> Memasak</label><br>
            <label><input type="checkbox" name="hobi[]" value="Tidur"> Tidur</label><br>
            <label><input type="checkbox" name="hobi[]" value="Makan"> Makan</label><br>

            <label class="form-label fw-semibold">Password</label><br>
            <input class="form-control" type="password" name="password"><br>

            <label class="form-label fw-semibold">Foto profil (opsional)</label><br>
            <input class="form-control" type="file" name="foto" accept="image/*">

            <button type="submit" class="mt-2 alert alert-danger w-100 rounded-3">Daftar</button>
        </form>

        <p>Sudah punya akun? <a href="login.php" class="text-decoration-none">Login di sini</a></p>
        </div>
    </div>
</body>
</html>
