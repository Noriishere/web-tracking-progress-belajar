<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="node_modules\bootstrap\dist\css\bootstrap.rtl.css" rel="stylesheet">
    <link href="node_modules\bootstrap-icons\font\bootstrap-icons.min.css" rel="stylesheet">
    <script src="node_modules\bootstrap\dist\js\bootstrap.min.js"></script>
    <title>Document</title>
</head>
<body>
    
</body>
</html>