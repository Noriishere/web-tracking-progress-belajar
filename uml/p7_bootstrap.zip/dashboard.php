<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$status_koneksi = $koneksi ? "Koneksi berhasil" : "Koneksi gagal";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h2>Aplikasi Data Mahasiswa (Demo)</h2>

    <p>Selamat datang, <?php echo htmlspecialchars($_SESSION['nama']); ?></p>
    <p>Email: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
    <p>Jenis Kelamin: <?php echo htmlspecialchars($_SESSION['jk']); ?></p>
    <p>Hobi: <?php echo htmlspecialchars($_SESSION['hobi']); ?></p>

    <?php if (!empty($_SESSION['foto'])): ?>
        <p>Foto profil:</p>
        <img src="uploads/<?php echo htmlspecialchars($_SESSION['foto']); ?>" alt="Foto Profil" width="120">
    <?php endif; ?><br>

    <p>Aplikasi ini digunakan untuk menyimpan dan menampilkan data mahasiswa.
       Data diambil dari proses registrasi yang mencakup nama, email, jenis kelamin, hobi dan foto profil.</p>

    <p>Status koneksi database: 
        <strong><?php echo $status_koneksi; ?></strong>
    </p>

    <p><a href="logout.php">Logout</a></p>
</body>
</html>
