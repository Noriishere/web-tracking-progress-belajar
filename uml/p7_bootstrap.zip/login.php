<?php
session_start();
require 'db.php';
include 'header.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if ($email == "" || $password == "") {
        $error = "Email dan password wajib diisi";
    } else {
        $sql  = "SELECT * FROM users WHERE email='$email' LIMIT 1";
        $res  = mysqli_query($koneksi, $sql);

        if (mysqli_num_rows($res) == 1) {
            $user = mysqli_fetch_assoc($res);

            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['nama']     = $user['nama'];
                $_SESSION['email']    = $user['email'];
                $_SESSION['jk']   = $user['jk'];
                $_SESSION['hobi'] = $user['hobi'];
                $_SESSION['foto']     = $user['foto'];

                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Password salah";
            }
        } else {
            $error = "Akun tidak ditemukan";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body class="bg-danger d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow rounded-4 p-3" style="witdh:20%;">
        <div class="card-body">
            <h4 class="mb-2">Login</h4>

            <div class="mt-2 mb-2 d-flex justify-content-center gap-3" >
                <a href="https://www.google.com" class="text-dark" ><i class="bi bi-google"></i></a>
                <a href="https://www.instagram.com" class="text-dark"><i class="bi bi-instagram"></i></a>
                <a href="https://www.facebook.com" class="text-dark"><i class="bi bi-facebook"></i></a>
                <a href="https://www.twitter.com" class="text-dark"><i class="bi bi-twitter-x"></i></a>
                <a href="https://www.github.com" class="text-dark"><i class="bi bi-github"></i></a>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
                <p style="color:green;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
            <?php endif; ?>

            <?php if ($error != ""): ?>
                <p style="color:red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <form action="" method="post">
                <label class="form-label fw-semibold">Email</label><br>
                <input class="form-control" type="email" name="email"><br>

                <label class="form-label fw-semibold">Password</label><br>
                <input class="form-control" type="password" name="password">

                <button class="mt-2 alert alert-danger w-100 rounded-3" type="submit">Login</button>
            </form>

            <p>Belum punya akun? <a href="register.php" class="text-decoration-none">Daftar dulu</a></p>
        </div>
    </div>
</body>
</html>
